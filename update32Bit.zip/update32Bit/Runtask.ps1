# === 1. Define Paths and URLs ===
$apiUrl = "https://server2.speqtagst.com/liveproject/api/speqtaconfig.json"
$configDir = "$env:LOCALAPPDATA\S_Task"
$configFile = "$configDir\app.config"
$logFile = "$configDir\activity.log"
$installPathFile = "$configDir\Installation.txt"

# === 2. Create Config Folder If It Doesn’t Exist ===
if (-not (Test-Path $configDir)) {
    New-Item -ItemType Directory -Path $configDir | Out-Null
}

# === 3. Logging Function ===
function Log {
    param ($msg)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $logFile -Value "[$timestamp] $msg"
}

# === 4. Read Remote Config ===
try {
    $response = Invoke-RestMethod -Uri $apiUrl -UseBasicParsing
    $task = $response.RunTask
} catch {
Log "ERROR: Failed to fetch config from server. Details: $_"
Write-Host "ERROR: Config fetch failed. Check activity.log for details." -ForegroundColor Red

    exit 1
}

# === 5. Read or Create Local Version ===
if (-not (Test-Path $configFile)) {
    "0" | Out-File $configFile -Encoding UTF8
}

try {
    $rawLocal = Get-Content $configFile | ForEach-Object { $_.Trim() } | Select-Object -First 1
    $localVersion = [int]$rawLocal
} catch {
    Log "Invalid version in config. Defaulting to 0."
    $localVersion = 0
}

$serverVersion = [int]$task.Version

# === 6. Compare Versions and Act Only If New ===
if ($serverVersion -gt $localVersion) {
    Log "New version found. Server: $serverVersion, Local: $localVersion"

    # --- Open URL ---
    if ($task.'Open URL') {
        $urlToOpen = "https://$($task.'Open URL')"
        Start-Process $urlToOpen
	#Start-Sleep -Seconds 2
	#Add-Type -AssemblyName System.Windows.Forms
	#[System.Windows.Forms.SendKeys]::SendWait("{F11}")
        Log "Opened URL in browser: $urlToOpen"
    }

    # --- Update Local Version ---
    Set-Content -Path $configFile -Value $serverVersion
    Log "Updated local version to: $serverVersion"

    # === 7. Get Install Path ===
    if (-not (Test-Path $installPathFile)) {
        Log "Installation path file not found: $installPathFile"
        exit 0
    }

    $installPath = Get-Content $installPathFile | ForEach-Object { $_.Trim() } | Select-Object -First 1

    if (-not (Test-Path $installPath)) {
        Log "Install path does not exist: $installPath"
        exit 0
    }

      # === 8. Handle Stop Tag (Multiple Processes) ===
if ($task.Stop) {
    $processesToStop = @()

    # Handle both string (single process) and array (multiple processes)
    if ($task.Stop -is [string]) {
        $processesToStop += $task.Stop
    } elseif ($task.Stop -is [System.Collections.IEnumerable]) {
        $processesToStop += $task.Stop
    }

    foreach ($proc in $processesToStop) {
        $procName = $proc.Trim() -replace ".exe$", ""

        try {
            Get-Process -Name $procName -ErrorAction Stop | Stop-Process -Force
            Log "Stopped process via Stop-Process: $procName"
        } catch {
            try {
                $tk = taskkill /F /IM "$procName.exe" 2>&1
                Log "Fallback taskkill for $procName.exe: $tk"
            } catch {
                Log "Failed to stop process $procName via both methods: $_"
            }
        }
    }
}


    # === 9. Handle Delete ===
    if ($task.Delete) {
        $fileToDelete = Join-Path $installPath $task.Delete
        if (Test-Path $fileToDelete) {
            try {
                Remove-Item $fileToDelete -Force
                Log "Deleted file: $fileToDelete"
            } catch {
                Log "Failed to delete file: $fileToDelete - $_"
            }
        } else {
            Log "File to delete not found: $fileToDelete"
        }
    }


    # === 10. Handle Download and Replace ===
  if ($task.Download) {
    try {
        $fileName = Split-Path -Leaf $task.Download
        $downloadPath = Join-Path $env:TEMP $fileName

        Invoke-WebRequest -Uri $task.Download -OutFile $downloadPath -UseBasicParsing
        Log "Downloaded ZIP to: $downloadPath"

        if ($downloadPath -like "*.zip") {
            try {
                # Extract to temporary path
                $tempExtractPath = Join-Path $env:TEMP "File_Extracted"
                if (Test-Path $tempExtractPath) {
                    Remove-Item $tempExtractPath -Recurse -Force
                }
                Expand-Archive -Path $downloadPath -DestinationPath $tempExtractPath -Force
                Log "Extracted ZIP to: $tempExtractPath"

                # Detect if there's a single root folder inside
                $subDirs = Get-ChildItem -Path $tempExtractPath -Directory
                if ($subDirs.Count -eq 1) {
                    $sourcePath = $subDirs[0].FullName
                } else {
                    $sourcePath = $tempExtractPath
                }

                # Copy contents to install path (NOT the folder itself)
                Get-ChildItem -Path $sourcePath -Recurse | ForEach-Object {
                    $relativePath = $_.FullName.Substring($sourcePath.Length).TrimStart('\')
                    $destination = Join-Path $installPath $relativePath

                    if ($_.PSIsContainer) {
                        if (-not (Test-Path $destination)) {
                            New-Item -ItemType Directory -Path $destination | Out-Null
                        }
                    } else {
                        Copy-Item -Path $_.FullName -Destination $destination -Force
                    }
                }

                Log "Copied contents of extracted ZIP to: $installPath"

                # Cleanup
                Remove-Item $tempExtractPath -Recurse -Force
                Remove-Item $downloadPath -Force
            } catch {
                Log "ZIP extraction or copy failed: $_"
            }
        }
    } catch {
        Log "Download failed: $_"
    }
}



} else {
    Log "Software is up to date. Local version: $localVersion"
}

# === Handle Selfdownload Tag ===
if ($task.Selfdownload) {
    try {
        $selfUrl = $task.Selfdownload.Trim()
        $fileName = Split-Path -Leaf $selfUrl
        $downloadPath = Join-Path $env:TEMP $fileName

        Invoke-WebRequest -Uri $selfUrl -OutFile $downloadPath -UseBasicParsing
        Log "Downloaded Selfdownload file to: $downloadPath"

        if ($downloadPath -like "*.zip") {
            try {
                $extractPath = $configDir

                # Clean the config dir if needed (optional, uncomment if required)
                # Remove-Item -Path $extractPath\* -Recurse -Force -ErrorAction SilentlyContinue

                Expand-Archive -Path $downloadPath -DestinationPath $extractPath -Force
                Log "Extracted Selfdownload ZIP to: $extractPath"

                # Optionally delete the zip after extraction
                Remove-Item $downloadPath -Force
            } catch {
                Log "Failed to extract Selfdownload ZIP: $_"
            }
        } else {
            Log "Selfdownload is not a ZIP file: $downloadPath"
        }
    } catch {
        Log "Failed Selfdownload processing: $_"
    }
}
